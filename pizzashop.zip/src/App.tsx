import './index.css'

export function App() {
  
  return (
    <h1>Hello </h1>
  )
}


